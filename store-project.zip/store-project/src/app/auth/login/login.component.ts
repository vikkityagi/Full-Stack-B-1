import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule,CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  constructor(private fb:FormBuilder){
    this.init();
  }

  loginForm: any = FormGroup;

  init(){
    this.loginForm = this.fb.group({
      user_name: [''],
      password: ['']
    })
  }

}
