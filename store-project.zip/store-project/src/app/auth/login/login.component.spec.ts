import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login.component';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      // declarations: [LoginComponent],
      imports: [ReactiveFormsModule]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the login form with default values', () => {
    expect(component).toBeTruthy();
    const loginForm = component.loginForm;
    expect(loginForm).toBeDefined();
    expect(loginForm.controls['user_name'].value).toEqual('');
    expect(loginForm.controls['password'].value).toEqual('');
  });

  it('should update the form value when input changes', () => {
    const loginForm = component.loginForm;
    const userNameInput = loginForm.controls['user_name'];
    const passwordInput = loginForm.controls['password'];

    userNameInput.setValue('testUser');
    passwordInput.setValue('testPassword');

    expect(component.loginForm.value).toEqual({ user_name: 'testUser', password: 'testPassword' });
  });

  it('should display form values in the template', () => {
    const compiled = fixture.nativeElement as HTMLElement;

    component.loginForm.controls['user_name'].setValue('testUser');
    component.loginForm.controls['password'].setValue('testPassword');
    fixture.detectChanges();

    const preElement = compiled.querySelector('pre');
    expect(preElement?.textContent).toContain('"user_name": "testUser"');
    expect(preElement?.textContent).toContain('"password": "testPassword"');
  });

  it('should render the form correctly', () => {
    const compiled = fixture.nativeElement as HTMLElement;

    // Check if the user name input is rendered
    const userNameInput = compiled.querySelector('input#user_name') as HTMLInputElement;
    expect(userNameInput).toBeTruthy();
    expect(userNameInput.placeholder).toBe('Enter user name here..');

    // Check if the password input is rendered
    const passwordInput = compiled.querySelector('input#password') as HTMLInputElement;
    expect(passwordInput).toBeTruthy();
    expect(passwordInput.placeholder).toBe('Enter user name here..');
  });
});
